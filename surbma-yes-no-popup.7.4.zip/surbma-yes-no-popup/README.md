CPS | Age Verification
======================

Shows a popup with age verification options. One of the best plugin for +18 adult sites or any sites, that requires any confirmation from a visitor.
